package ch15.sec06.exam02;

public class Message {
    public String commmand;
    public String to;

    public Message(String commmand, String to) {
        this.commmand = commmand;
        this.to = to;
    }
}
